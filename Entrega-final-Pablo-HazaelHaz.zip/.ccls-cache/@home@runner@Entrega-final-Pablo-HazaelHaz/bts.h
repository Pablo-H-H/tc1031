#ifndef BTS_H
#define BTS_H

#include <queue>
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

template <class T> class BST;

template <class T> class Node {

public:
  T value;
  std::string nombre;
  int value2;
  Node *left, *right;

  Node(T);
  Node(T , std::string , int);
  void add(T, std::string , int);
  void preorder(Node<T> *, std::stringstream &);
  void inorder(Node<T> *, std::stringstream &);
  void postorder(Node<T> *, std::stringstream &);
  void levelOrder(Node<T> *, std::stringstream &);
  string find(Node<T>*, T, stringstream &);

  friend class BST<T>;
};

template <class T>
Node<T>::Node(T val, std::string nom, int val2) : value(val), nombre(nom), value2(val2), left(0), right(0) {}

template <class T> 
void Node<T>::add(T val, std::string nom, int val2) {
  if (val <= value) {
    if (left == NULL) {
      Node<T> * nuevo_nodo = new Node<T>(val, nom, val2);
      if (nuevo_nodo == NULL) {

      }
      left = nuevo_nodo;
    } else {
      left->add(val, nom, val2);
    }

  } else {
    if (right == NULL) {
      Node<T> * nuevo_nodo = new Node<T>(val, nom, val2);
      if (nuevo_nodo == NULL) {

      }
      right = nuevo_nodo;
    } else {
      right->add(val, nom, val2);
    }
  }
}

template <class T>
void Node<T>::preorder(Node<T> *nodo, std::stringstream &ss) {

  ss << nodo->nombre << ", " << nodo -> value << "," << nodo-> value2 << ",\n";
  if (nodo->left != 0) {
    ss << " ";
    nodo->left->preorder(nodo->left, ss);
  }
  if (nodo->right != 0) {
    ss << " ";
    nodo->right->preorder(nodo->right, ss);
  }
}

template <class T> void Node<T>::inorder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo->left != 0) {
    nodo->left->inorder(nodo->left, ss);
  }
  std::string content = ss.str();
  char lastCharacter = content[content.length() - 1];

  if (lastCharacter != '[') {
    ss << "";
  }
  ss << nodo->nombre << "," << nodo -> value << "," << nodo-> value2 << ",\n";
  if (nodo->right != 0) {
    nodo->right->inorder(nodo->right, ss);
  }
}

template <class T>
void Node<T>::postorder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo != 0) {
    postorder(nodo->left, ss);
    postorder(nodo->right, ss);

    std::string content = ss.str();
    char lastCharacter = content[content.length() - 1];

    if (lastCharacter != '[') {
      ss << " ";
    }

    ss << nodo->nombre << ", " << nodo -> value << "," << nodo-> value2 << ",\n";
  }
}

template <class T>
void Node<T>::levelOrder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo == NULL) {
    return;
  }

  std::queue<Node<T> *> q;
  q.push(nodo);

  while (!q.empty()) {
    Node<T> *current = q.front();
    q.pop();
    if (current != NULL) {
      std::string content = ss.str();
      char lastCharacter = content[content.length() - 1];

      if (lastCharacter != '[') {
        ss << " ";
      }
      ss << current->value;
      q.push(current->left);
      q.push(current->right);
    }
  }
}
template <class T> 
string Node<T>::find(Node<T>* nodo, T val, stringstream &ss) {
  if (val == value) {
    ss << nombre << "," << value << "," << value2 << ",\n";
    if(left != NULL){
      return left->find(nodo, val, ss);
    }
    if(right != NULL){
      return right->find(nodo, val, ss);
    }
    return ss.str();
  }

  if (val < value) {
    if (left == NULL) { // Con esto ya no se sigue
      return ss.str();
    }
    return left->find(nodo, val, ss); // Regresamos resultado de la busqueda
  } else {
    if (right == NULL) { // Con esto ya no se sigue
      return ss.str();
    }
    return right->find(nodo, val, ss); // Regresamos resultado de la busqueda
  }
}


template <class T> class BST {

public:
  Node<T> *root;
  BST();
  void add(T, std::string , int);
  std::string visit();
  void preorder(Node<T> *, std::stringstream &);
  void inorder(Node<T> *, std::stringstream &);
  void postorder(Node<T> *, std::stringstream &);
  void levelOrder(Node<T> *, std::stringstream &);
  int height();
  string find(T) const;
  int height(Node<T> *);
};

template <class T> BST<T>::BST() : root(0) {}

template <class T> void BST<T>::add(T val, std::string nom, int val2) {

  Node<T> *newNode = new Node<T>(val, nom, val2);
  if (root == 0) {
    root = newNode;
  } else //if (val != root->value)
  {
    root->add(val, nom, val2);
  }
}

template <class T> 
string BST<T>::find(T val) const {
  if (root == NULL) {
    return NULL;
  }

  stringstream ss;
  return root->find(root, val, ss);
}

template <class T> 
std::string BST<T>::visit() {

  std::stringstream ss;


  // Inorder
  inorder(root, ss);

  return ss.str();
}

template <class T> 
void BST<T>::preorder(Node<T> *nodo, std::stringstream &ss) {

  ss << nodo->nombre << ", " << nodo -> value << "," << nodo-> value2 << ",\n";
  if (nodo->left != 0) {
    ss << "";
    nodo->left->preorder(nodo->left, ss);
  }
  if (nodo->right != 0) {
    ss << "";
    nodo->right->preorder(nodo->right, ss);
  }
}

template <class T> void BST<T>::inorder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo->left != 0) {
    nodo->left->inorder(nodo->left, ss);
  }

  std::string content = ss.str();
  char lastCharacter = content[content.length() - 1];

  if (lastCharacter != '[') {
    ss << "";
  }
  ss << nodo->nombre << ", " << nodo -> value << "," << nodo-> value2 << ",\n";
  if (nodo->right != 0) {
    nodo->right->inorder(nodo->right, ss);
  }
}

template <class T>
void BST<T>::postorder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo != 0) {
    postorder(nodo->left, ss);
    postorder(nodo->right, ss);

    std::string content = ss.str();
    char lastCharacter = content[content.length() - 1];

    if (lastCharacter != '[') {
      ss << " ";
    }

    ss << nodo->nombre << ", " << nodo -> value << "," << nodo-> value2 << ",\n";
  }
}

template <class T>
void BST<T>::levelOrder(Node<T> *nodo, std::stringstream &ss) {

  if (nodo == nullptr) {
    return;
  }

  std::queue<Node<T> *> q;
  q.push(nodo);

  while (!q.empty()) {
    Node<T> *current = q.front();
    q.pop();
    if (current != nullptr) {
      std::string content = ss.str();
      char lastCharacter = content[content.length() - 1];

      if (lastCharacter != '[') {
        ss << " ";
      }
      ss << current->value;
      q.push(current->left);
      q.push(current->right);
    }
  }
}

template <class T> int BST<T>::height() {

  if (root == NULL) {
    return 0; // La altura de un árbol vacío es 0
  } else {

    int leftHeight = height(root->left);
    int rightHeight = height(root->right);

    if(leftHeight > rightHeight){
      return leftHeight + 1;
    } else{
      return rightHeight + 1;
    }
  }
}

template <class T> int BST<T>::height(Node<T> *nodo) {
  if (nodo == NULL) {
    return 0; 
  } else {
    int leftHeight = height(nodo->left);
    int rightHeight = height(nodo->right);

   if(leftHeight > rightHeight){
      return leftHeight + 1;
    } else{
      return rightHeight + 1;
    }
  }
}

#endif