#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <sstream>
#include "bts.h"
#include <vector>

using namespace std;

int tamanio_lista(){
  ifstream archivo ("Lista.csv", ios::in);
  string registro;
  int size = 0;
  while(getline(archivo,registro)){
    size ++;
  }
  return size;
}

void Orden(){
  cout << "\nTe gustaria la lista de mayor a menor o menor a mayor? \n 1 - Mayor a menor  \n 2 - Menor a mayor" << endl;
}

void guardar(){
  cout << "\nTe gustaria guardar la lista ordenada aparte? \n 1 - Si \n 2 - No" << endl;
}

BST<int> OrdenamientoBTS(vector<string> &prueba_nombre, vector<int> &prueba_cantidad, vector<int> &prueba_precio) {

  int size = tamanio_lista();
  BST<int> bts;

  for(int i = 0; i < size; i++){
    bts.add(prueba_cantidad[i], prueba_nombre[i], prueba_precio[i]);
  }

  return bts;
}

string OrdenInverso(string lista){
  stringstream ss;
   int i = 0;
  int size = tamanio_lista();
  string nombre_lista[size];

  string lectura;

  stringstream input_stringstream(lista);
  while (getline(input_stringstream, lectura, '\n'))
  {
    nombre_lista[i] = lectura;
    i++;
  }
  while(i > 0){
    ss << nombre_lista[i - 1] << endl;
    i--;
  }
  return ss.str();
}


void exportToCSV (string x) {

  //system("clear");
  //system("cls");

  ofstream archivo;
  archivo.open("ListaOrdenada.csv", ios::out);

  archivo << x;
  archivo.close();
  cout << "\nLista guardada con exito\n" << endl;
}


int main() {

  string registro;
  string nombre, cantidad, precio;

  vector<string> prueba_nombre;
  vector<int> prueba_cantidad;
  vector<int> prueba_precio;

  int opc = 0;
  int opc2 = 0;
  int opc3 = 0;


  while (opc != 5){

    int size = tamanio_lista();
    ifstream archivo ("Lista.csv", ios::in);

    string nombre_lista[size];
    int cantidad_lista[size];
    int precio_lista[size];

    int i = 0;  
    while(getline(archivo, registro)){
      stringstream token(registro); 

      getline(token, nombre, ',');
      getline(token, cantidad, ',');
      getline(token, precio, ',');

      nombre_lista[i] = nombre;

      cantidad_lista[i] = stoi(cantidad);

      precio_lista[i] = stoi(precio);


      i++;
    }

    archivo.close();


    vector<string> vector_nombre(nombre_lista, nombre_lista + sizeof(nombre_lista) / sizeof(string));

    vector<int> vector_cantidad(cantidad_lista, cantidad_lista + sizeof(cantidad_lista) / sizeof(int));

    vector<int> vector_precio(precio_lista, precio_lista + sizeof(precio_lista) / sizeof(int));


    prueba_nombre = vector_nombre;
    prueba_cantidad = vector_cantidad;
    prueba_precio = vector_precio;

    BST<int> bts, bts_cantidad, bts_precio;
    bts_cantidad = OrdenamientoBTS(prueba_nombre, prueba_cantidad, prueba_precio);
    bts_precio = OrdenamientoBTS(prueba_nombre, prueba_precio, prueba_cantidad);


    cout << "Que desas realizar? \n 1 - Organizar por Cantidad \n 2 - Organizar por Precio \n 3 - Anadir a la lista \n 4 - Buscar \n 5 - Salir" << endl;
    cin >> opc;

    switch(opc){
      case 1:{
        bts = bts_cantidad;
        string lista;
        Orden();
        cin >> opc2;
        switch(opc2){
          case 1:{
            lista = OrdenInverso(bts.visit());
            std::cout << lista << endl<< endl;
            guardar();
            cin >> opc3;
            switch(opc3){
              case 1:
                exportToCSV(lista);
                break;
              case 2:
                break;
            }
            break;
          }
          case 2:{
            lista = bts.visit();
            cout << lista << endl;
            guardar();
            cin >> opc3;
            switch(opc3){
              case 1:
                exportToCSV(lista);
                break;
              case 2:
                break;
            }
            break;
          }
        }
        break;
      }

      case 2:{
        bts = bts_precio;
        string lista;
        Orden();
        cin >> opc2;
        switch(opc2){
          case 1:{
            lista = OrdenInverso(bts.visit());
            std::cout << lista << endl<< endl;
            guardar();
            cin >> opc3;
            switch(opc3){
              case 1:
                exportToCSV(lista);
                break;
              case 2:
                break;
            }
            break;
          }
          case 2:{
            lista = bts.visit();
            cout << lista << endl;
            guardar();
            cin >> opc3;
            switch(opc3){
              case 1:
                exportToCSV(lista);
                break;
              case 2:
                break;
            }
            break;
          }
        }
        break;
      }


      case 3:{
        ofstream archivo("Lista.csv", ios::app);
        cout << "Nombre: " << endl;
        cin >> nombre;

        cout << "Cantidad: " << endl;
        cin >> cantidad;

        cout << "Precio: " << endl;
        cin >> precio;

        archivo << "\n" << nombre << "," << cantidad << "," << precio << ",";
        archivo.close ();

        cout << "Se ha añadido el producto a la lista" << endl;
      break;
      }

      case 4:{
        string res;
        cout << "\nPrecio o Cantidad? \n1 - Precio \n2 - Cantidad" << endl;
        cin >> opc2;
        switch(opc2){
          case 1:{
            cout << "\nEscribe el Precio:\n" << endl;
            cin >> opc3;
            bts = bts_precio;
            res = bts.find(opc3);
            if (res != ""){
              cout << "\n" << res << endl;
            }else{
              cout << "\n No existe un producto con ese Precio" << endl;
            }
            break;
          }
          case 2:{
            cout << "\nEscribe la Cantidad:\n" << endl;
            cin >> opc3;
            bts = bts_cantidad;
            res = bts.find(opc3);
            if (res != ""){
              cout << "\n" << res << endl;
            }else{
              cout << "\n No existe un producto con esa cantidad" << endl;
            }
            break;
          }
        }
      }

    }
  }

  cout << "Gracias por Visitarnos!!!" << endl;

}