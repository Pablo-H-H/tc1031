# Proyecto: Ordenador de Inventario
Este programa le permite al usuario ver los datos que se encuentran en el archivo Lista.csv y lo puede visualizar como una lista ordenada por cantidad de componentes o por el precio de estos, puedes ordenar de mayor a menor o de manera inversar, y se puede usar el metodo de ordenamiento BubleSort o QuickSort. Finalmente le permite al usuario anadir mas componentes a la lista y la lista los guarda.

## Descripción del avance 1
Se implementaron los dos sistemas de ordenamiento (BubbleSort y Quicksort) tanto de mayor a menor como menor a mayor. Se implemento el sistema para anadir mas objetos a la lista y se diseno la interfaz de usuario

## Descripción del avance 2
El programa ahora le permite al usuario decidir si quiere exportar su lista ya ordenada como un archivo aparte de formato .csv, si el usuario selecciona que si entonces el programa crea el archivo con el nombre ListaOrdenada.csv que contiene la informacion ya ordenada y con el mismo formato que la Lista.csv por si el usuario quiere usarlo.


### Cambios sobre el primer avance
La idea de crear un programa que solo ordene la lista evolucionó y ahora le permite al usuario exportar la lista ordenada para que sea utilizada por el usuario.

## Descripción del avance 3
El sistema ahora utiliza un estrucura de datos la cual le permite hacer busquedas mas eficientes.

### Cambios sobre el segundo avance
1. Escribe la lista de cambios realizados sobre el planteamiento pasado: Argumenta la razón por la que decidiste el cambio. Estos argumentos puedes retomarlos más adelante en tu argumentación de competencias.
2. Cambio 2: Razón del cambio
3. Cambio 3: Razón del cambio
4. etc...: etc...

## Instrucciones para compilar el avance de proyecto

Ejecuta el siguiente comando en la terminal:

`g++ bts.h Lista.csv main.cpp -o tercer_avance`

## Instrucciones para ejecutar el avance de proyecto
Ejecuta el siguiente comando en la terminal:

`./tercer_avance` 

Si se ejecuta en replit se puede usar el boton de "Run" para copilarlo y ejecutarlo

## Descripción de las entradas del avance de proyecto
El proyecto usa una lista tipo .csv con 3 filas: nombre, cantidad y precio. Cuando el usuario selecciona las diferentes opciones el usuario tiene que usar numeros y palabras respectivamente se pidan.

## Descripción de las salidas del avance de proyecto
El programa te devolvera la lista que metiste de manera ordenada usando dos diferentes metodos dependiendo de lo que pidas, en el caso de que modifiques la lista esta se actualizara en el archivo .csv y la siguiente vez que uses un sort en la consola la lista estara actualizada. Los ordenamientos son realizados internamente y mostrados solo en consola, y en esta avance se implemento la funcion de guiardarlos en una lista que puede ser consultada como ListaOrdenada.txt.

## Desarrollo de competencias

### SICT0301: Evalúa los componentes
#### Hace un análisis de complejidad correcto y completo para los algoritmos de ordenamiento usados en el programa.
Si lograste este criterio anteriormente, copia aquí tu argumentación. Si no, ésta es una nueva oportunidad para lograrlo. Escribe aquí tu aprendizaje y tus argumentos sobre por qué consideras que ahora ya has desarrrollado este criterio y dónde se puede observar el desarrollo que mencionas.

#### Hace un análisis de complejidad correcto y completo de todas las estructuras de datos y cada uno de sus usos en el programa.
La lectura de la lista para guardala en listas separadas tiene una complejidad de O(n) considerando que n es el numero de lineas que tiene el arcivo
El arbol binario tiene una complejidad de insercion y busqueda de O(log n) cada uno , esto lo podemos encontrar en la Big-O Cheat Sheet, esto seria cierto si tuvieramos un arbol el cual se autonivela. Una vez que consideramos todo esto encontramos que el arbol puede tener un complejidad de busqueda de O(n) en donde se dice que se va tener que recorrer toda la estructura para encontrar el numero deseado. Con esto encontramos que nuestra estructura, al ser O(n) nuestro caso mas complejo, decimos con certesa que la complejidad final de nuestro estructura de arbol binario es de O(n)

#### Hace un análisis de complejidad correcto y completo para todos los demás componentes del programa y determina la complejidad final del programa.
Otro de los componentes que mas complejidad tiene este algortmo podemos decir que es el lector de archivos, esto es debido que por cada fila i tenemos n filas, y leer cada una de estas lineas nos da que este algoritmo tiene una complejidad de O(i * (n = 3) donde i es el numero de filas y n es nuestras columnas, en donde tendremos 3 columnas siempre.
Otro de los componentes que tenemos es el OrdenInverso donde podemos ver de nuevo una complejidad parecida a la anterior en donde tambien guardamos las filas de una lista, pero en esta ocasion cambiamos la lista de orientacion y por lo mismo la volvemos a recorrer, o lo equivalente a una complejidad de O(n * 2) donde n es el numero de filas que tiene una lista
Tambien encontramos que Ordenamiento BST tiene la concatenacion de tres listas, como solo pasa 1 ves las listas y las concatena al mismo tiempo, esto nos indica que tenemos una complejidad de O(n) donde n es el tamanio de la lista que recorremos.

Por otra parte recordemos que nuestra estructura de datos tiene una complejidad de O(n), mientras que nuestra mayor complejidad del programa es de O(n*3). Como nuestra mayor complejidad del programa es de O(n * 3) podemos decir con confianza que este es nuestra ocomplejidad final del programa

### SICT0302: Toma decisiones
#### Selecciona un algoritmo de ordenamiento adecuado al problema y lo usa correctamente.
El algoritmo de ordenamiento que tiene el arbol es uno binario, este sistema de ordenamiento lo considero adecuado ya que este programa esta pensado para leer y ordenar archivos que tienen contenidos desordenados, al usar este ordenamiento se piensa que el usuario solo lo use para hacer consultas y ordenamientos rapidos, por lo que un sistema mas complejo no seria tan beneficioso ya que estos tiene una complejidad similar en casi todos los casos.
Un benefisio extra de usar este sistema de ordenamiento es que al no ser tan grande el programa, se puede implementar mas facil en una caja registradora por ejemplo.

#### Selecciona una estructura de datos adecuada al problema y la usa correctamente.
La estructura de datos usada en este programa es el arbol binario, este arbol se utiliza porque se espera que el orden de los datos que vayan entrando sean en desorden y que este programa sea usado especificamente para ordenarlos y hacer consultas rapidas, no esta diseniado para anadir datos en el programa, auqnue este le permite hacerlo si le conviene al usuario. Tambien con esta decision necesitamos considerar las diferentes complejidades que estas tienen en comparacion con una estructura lineal como es una lista ligada o una lista doblemente ligada. Tomando esto en cuenta decidimos usar una estructura de arbol binaria por las siguientes complejidades:
Singly Linked List:  Search O(n) InsertionO(1)
Doubly Linked List: Search O(n) Insertion O(1)
Arbol BTS Tienes dos casos en search porque este no se autobalancea:
Search Mejor caso O(logn) Peor caso O(n) 
Insertion O(log n)
Con esto podemos encontrar que incluso cuando tenemos una estructura bien pensada como puede ser un arbol binario, podemos obtener mejores resultados que usando una lista Liga.
Finalmente otro beneficio del uso de un arbol binario es que con el uso de nodos podemos asigrnales diferentes propiedades a cada nodo, por lo que nos ayuda a ordenar una lista con varios y diferentes datos como es el caso, donde usamos strings e ints.

### SICT0303: Implementa acciones científicas
#### Implementa mecanismos para consultar información de las estructras correctos.
El sistema actual es un arbol binario, este arbol binario tiene diferentes tipos de consultas el cual puede realizar, dentro de estos estoy utilizando el sistema de ordenamiento llamado inorder(), lo que me permite, que a pesar que es una arbol binario, poder consultar todos los datos de  una manera ordenada. La forma en la que se consultan los datos en este arbol para el inorder es: Dato izquierdo, Dato medio, Dato derecha, con este orden de consulta se puede imprimir el arbol de manera ordenada
La estructura de arbol tambien nos permite tener un sistema de busqueda mas eficiente relativo a una lista concatenada, esto es a menos que se el arbol este deformado, lo que reduce su grandemente efectividad, en la busqueda del arbol se utiliza una busqueda binaria, y la eficiencia de esta va a depender de que tanto se deforme el arbol, en este caso como el arbol no se auto-ordenar, su efectividad varia grandemnete realativa al tamanio de la lista.  
#### Implementa mecanismos de lectura de archivos para cargar datos a las estructuras de manera correcta.
En el main se encuentra una forma de leer el archivo Lista.h, esto se lleva a cabo a travez del comando ifstream con ios::in, lo que nos permite abrir los archivos en forma de lectura. Con el comando getline(archivo, registro) podemos ir leyendo linea por linea y finalmente el comando getline(token, variable, ',') nos permite leer solo hasta la coma y lo guarda en "variable".
Este metodo de lectura nos permite tener una precision y orden en la lectura sin perder la posibilidad de escribir palabras compuestas como en el caso del item "Pantalla LCD".

### Implementa mecanismos de escritura de archivos para guardar los datos  de las estructuras de manera correcta
El pedazo de codigo que ayuda con el guardado correcto de la lita es el sieguiente:

void exportToCSV(string x) {

  system("clear");
  system("cls");

  ofstream archivo;
  archivo.open("ListaOrdenada.csv", ios::out);

  archivo << x;
  archivo.close();
  cout << "\nLista guardada con exito\n" << endl;
}

Este codigo tiene lo necesario para crear un archivo llamado: "ListaOrdenada.csv" en el cual se va a guardar la lista en el modo de ordenamiento que tienes elegido.
El codigo recive un string el cual se va  insertar en el nuevo archivo, con el ofstream archivo nos permite crear un archivo y modificarlo, finalmente cuando se termina de modificar, el archivo se cierra y se imprime el texto: "\nLista guardada con exito\n"